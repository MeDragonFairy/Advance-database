//package modules
const { request } = require('express');
const express=require('express');
const mysql      = require('mysql');

const connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'twisters'
});
 
connection.connect( (err) => {
    if(err){
        console.log("Error in database connection");
        return;
    }
    console.log("Database connected successfully!")
});

const app = express();
app.use(express.urlencoded({ extended: false }));
app.use('/static', express.static(__dirname + '/client/public'));
app.set('views', __dirname+'/client/views');
app.set('view engine', 'ejs');

app.get('/', function (req, res, next){
    res.render('index', {
        "title" : "Home",
        "Path" : ""
    })
});

app.get('/about', function (req, res, next){
    res.render('about', {
        "title" : "About",
        "Company" : "Twisters",
        "Path" : ""
    })
});

app.get('/contact', function (req, res, next){
    res.render('contact', {
        "title" : "Contact",
        "Path" : ""
    })
});


app.post('/contact-data', function (req, res, next){
    let addContact = {
        firstname: req.body.firstname,
        lastname: req.body.lastname,
        email: req.body.email,
        message: req.body.message
    }
    
    let sql = "INSERT INTO contact SET ?";
    
    connection.query( sql, addContact, (err) => {
        if(err){
            res.status(201).redirect("/contact");
        }
        console.log("Contact added successfully");
    })

    res.status(200).redirect("/contact");
});


app.get('/faq', function (req, res, next){
    res.render('faq', {
        "title" : "Faq",
        "Path" : ""
    })
});


app.get('/events/:id?', function (req, res, next){
    let path = "";

    if(req.params.id){
        path = "../";
    }

    res.render('events', {
        "title" : "Events",
        "Company" : "Twisters",
        "Path" : path
    })
    next();
});

app.get('/events-data/:id?', function (req, res){
    let sql = `SELECT * FROM event`;
    if(req.params.id){
        sql = `SELECT * FROM area_event LEFT JOIN event ON area_event.event = event.id WHERE area = ${req.params.id}`;
    }
    
    
    connection.query( sql, (err, data, fields) => {
        if(err){
            res.status(201).json({
                "eventData" : null
            });
        }

        res.status(200).json({
            "eventData" : data
         });
    })
});



app.listen(3000, ()=>{ console.log('Server started at port : 3000')});