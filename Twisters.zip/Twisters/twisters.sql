-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2022 at 04:08 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `twisters`
--

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE `area` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'chicago', '2022-01-19 05:46:24', '2022-01-19 05:46:24'),
(2, 'toronto', '2022-01-19 05:46:24', '2022-01-19 05:46:24'),
(3, 'hollywood', '2022-01-19 05:46:36', '2022-01-19 05:46:36');

-- --------------------------------------------------------

--
-- Table structure for table `area_event`
--

CREATE TABLE `area_event` (
  `id` int(11) NOT NULL,
  `area` int(11) NOT NULL,
  `event` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `area_event`
--

INSERT INTO `area_event` (`id`, `area`, `event`, `created_at`, `updated_at`) VALUES
(1, 1, 18, '2022-01-19 11:42:54', '2022-01-19 11:42:54'),
(2, 1, 19, '2022-01-19 11:42:54', '2022-01-19 11:42:54'),
(3, 2, 20, '2022-01-19 11:43:17', '2022-01-19 11:43:17'),
(4, 2, 21, '2022-01-19 11:43:17', '2022-01-19 11:43:17'),
(5, 3, 22, '2022-01-19 11:43:35', '2022-01-19 11:43:35'),
(6, 3, 23, '2022-01-19 11:43:35', '2022-01-19 11:43:35');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `firstname`, `lastname`, `email`, `message`, `created_at`, `updated_at`) VALUES
(0, 'Mohsin', 'Shahzad', 'm@gmail.com', 'asdasdasdas', '2022-01-19 06:28:06', '2022-01-19 06:28:06'),
(0, 'Mohsin', 'Shahzad', 'a@gmail.com', 'I have this issue', '2022-01-19 06:29:06', '2022-01-19 06:29:06'),
(0, 'mohsin', 'Shahzad', 'admin@extrapoints.com', 'okayokay', '2022-01-19 06:31:01', '2022-01-19 06:31:01');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `host` varchar(50) NOT NULL,
  `time` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `name`, `host`, `time`, `created_at`, `updated_at`) VALUES
(1, 'we are were we were', 'chris turner', '2020-11-12 13:59:49', '2022-01-19 05:50:07', '2022-01-19 05:50:07'),
(2, 'the last one', 'bronwyn sweeney', '2020-12-16 13:59:31', '2022-01-19 05:52:29', '2022-01-19 05:52:29'),
(3, 'the one who speaks french', 'ed macarthur', '2021-01-09 13:59:14', '2022-01-19 05:52:29', '2022-01-19 05:52:29'),
(4, 'The one with the birth mother', 'tamer kattan', '2021-03-18 13:58:58', '2022-01-19 05:54:11', '2022-01-19 05:54:11'),
(5, 'late thanksgiving', 'sarah callaghan', '2021-04-30 13:58:44', '2022-01-19 05:54:11', '2022-01-19 05:54:11'),
(6, 'home study', 'patrick monahan', '2021-05-22 13:58:29', '2022-01-19 05:55:52', '2022-01-19 05:55:52'),
(7, 'Memorial Service', 'david hoare', '2021-06-11 13:57:47', '2022-01-19 05:55:52', '2022-01-19 05:55:52'),
(8, 'soap opera party', 'hathy maniura', '2021-07-11 13:57:32', '2022-01-19 05:56:59', '2022-01-19 05:56:59'),
(9, 'Lottery', 'prince abdi', '2021-08-07 13:57:19', '2022-01-19 05:56:59', '2022-01-19 05:56:59'),
(10, 'christmas in tulsa', 'christy coysh', '2021-08-20 13:56:40', '2022-01-19 05:59:18', '2022-01-19 05:59:18'),
(11, 'the one with the pediatrician', 'grace campbell', '2021-09-15 13:56:24', '2022-01-19 05:59:18', '2022-01-19 05:59:18'),
(12, 'cooking class', 'ginnia cheng', '2021-10-07 13:56:13', '2022-01-19 06:00:25', '2022-01-19 06:00:25'),
(13, 'late comers', 'arielle souma', '2021-10-13 13:55:59', '2022-01-19 06:00:25', '2022-01-19 06:00:25'),
(14, 'Candy hearts', 'emily bampton', '2021-11-27 13:55:41', '2022-01-19 06:04:35', '2022-01-19 06:04:35'),
(15, 'stoned guy', 'davina bentley', '2021-12-01 13:55:24', '2022-01-19 06:04:35', '2022-01-19 06:04:35'),
(16, 'all the poker', 'archie maddocks', '2021-12-23 13:55:12', '2022-01-19 06:06:19', '2022-01-19 06:06:19'),
(17, 'baby on the bus', 'jen ives', '2022-01-04 13:54:57', '2022-01-19 06:06:19', '2022-01-19 06:06:19'),
(18, 'Long list', 'karen hobbs', '2022-01-20 13:53:35', '2022-01-19 06:07:13', '2022-01-19 06:07:13'),
(19, 'super bowl', 'jack barry', '2022-01-21 13:53:44', '2022-01-19 06:07:13', '2022-01-19 06:07:13'),
(20, 'moving out', 'jo coffey', '2022-01-22 13:53:56', '2022-01-19 06:08:12', '2022-01-19 06:08:12'),
(21, 'the one with the bullies', 'hassan dervish', '2022-01-23 13:54:06', '2022-01-19 06:08:12', '2022-01-19 06:08:12'),
(22, 'flashback', 'ruby keane', '2022-01-24 13:54:18', '2022-01-19 06:09:13', '2022-01-19 06:09:13'),
(23, 'winter is coming', 'helen bauer', '2022-01-25 13:53:10', '2022-01-19 06:09:13', '2022-01-19 06:09:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `area_event`
--
ALTER TABLE `area_event`
  ADD PRIMARY KEY (`id`),
  ADD KEY `area` (`area`),
  ADD KEY `event` (`event`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `area`
--
ALTER TABLE `area`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `area_event`
--
ALTER TABLE `area_event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `area_event`
--
ALTER TABLE `area_event`
  ADD CONSTRAINT `area_event_ibfk_1` FOREIGN KEY (`area`) REFERENCES `area` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `area_event_ibfk_2` FOREIGN KEY (`event`) REFERENCES `event` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
