window.onload  = function(){

    let eventsResults = document.getElementById("events-results-container");
    let eventSeach = document.getElementById("seach");
    let html="";
    let eventData="";
    let urlId="";

    urlId = window.location.href.split("/").pop();
    
    if(isNaN(urlId)){
        urlId = "/events-data";
    }else{
        urlId = "/events-data/" + urlId;
    }

    fetchData(urlId);

    function appendHtml(item){
        return `<div class="card">
                    <div class="title">
                        <h1>${ item.name }</h1>
                    </div>
                    <div class="content">
                        <div class="social">
                            <i class="fas fa-user"></i>
                            <a href="#">${ item.host }</a>
                        </div>
                
                        <div class="social">
                            <i class="fas fa-calendar"></i>
                            <a href="#">${ item.time.substring(0, 10) }</a>
                        </div>
                    </div>
                </div>`;
               
    }

    function fetchData(urlId){
        fetch(urlId, {
            method : "GET"
        })
        .then( response => response.json())
        .then( data => {
            html = ``;
    
            data.eventData.forEach((item)=> {
                html += appendHtml(item);
            })
    
            html += `</div>`;
    
            eventsResults.innerHTML = html;
        })
        .catch(err => {
            console.error(err);
        })
    }


    
    // when no data is fetched
    const noData = () => {
        return `<div class="card">
                    <div class="title">
                        <h1>Sorry! No data found!</h1>
                    </div>
                </div>`;
    }


    // fetching for searching
    const searchData = (inp, urlId) => {
        fetch(urlId, {
            method : "GET"
        })
        .then( response => response.json())
        .then( data => {
            eventsResults.innerHTML = '';
            html = "";
            data.eventData.forEach((item)=> {
                if(item.name.toLowerCase().includes(inp) || item.host.toLowerCase().includes(inp) || item.time.substring(0, 10).includes(inp) ){
                    html += appendHtml(item);
                }
            })
            
            if(html === ""){
                eventsResults.innerHTML = '';
                html += noData();
            }

            eventsResults.innerHTML = html;

        })
        .catch(err => {
            html += noData();
            eventsResults.innerHTML = html;
        })
    }

    // search on input
    eventSeach.addEventListener("input", (item) => {
        searchData(item.currentTarget.value.toLowerCase(), urlId);
    })

    
}