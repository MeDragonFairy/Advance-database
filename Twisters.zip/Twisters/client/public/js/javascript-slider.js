var imgArray = new Array();

imgArray[0] = new Image();
imgArray[0].src = 'static/imgs/slider/s1.jpg';

imgArray[1] = new Image();
imgArray[1].src = 'static/imgs/slider/s2.jpg';

imgArray[2] = new Image();
imgArray[2].src = 'static/imgs/slider/s3.jpg';

var i=1;

        var runImgChanger;

        var next = document.querySelector("#right-arrow");
        var prev = document.querySelector("#left-arrow");

        // Code that moves to the next slide
        next.addEventListener("click", function () {
                clearInterval(runImgChanger);
                changeSlide();
                runImgChanger= setInterval(changeSlide, 3000);
        });

        // Code that moves to the previous slide
        prev.addEventListener("click", function () {
                clearInterval(runImgChanger);
                i--;
                if(i== -1){
                        i=imgArray.length-1;
                }
                document.getElementById("slider-img").src = imgArray[i].src;

                runImgChanger= setInterval(changeSlide, 3000);
        });

        function changeSlide(){
                document.getElementById("slider-img").src = imgArray[i].src;
                i++;

                if(imgArray.length <= i){
                        i=0;
                }
        }
        
        runImgChanger= setInterval(changeSlide, 3000);