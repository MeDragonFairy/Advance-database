function myFunction(){
    var firstName = document.getElementById('first-name').value;
    var lastName = document.getElementById('last-name').value;
    var email = document.getElementById('email').value;
    var description = document.getElementById('description').value;

    if(firstName.length > 0  && lastName.length > 0  && email.length > 0  && description.length > 0 ){
        document.getElementById('submit').className = "btn contact-form-button";
        document.getElementById('submit').style.pointerEvents = "auto";
    }else{
        document.getElementById('submit').className = "btn contact-form-button disabled";
        document.getElementById('submit').style.pointerEvents = "none";
    }
}

document.getElementById("first-name").addEventListener("keyup", myFunction);
document.getElementById("last-name").addEventListener("keyup", myFunction);
document.getElementById("email").addEventListener("keyup", myFunction);
document.getElementById("description").addEventListener("keyup", myFunction);